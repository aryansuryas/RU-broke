import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  motion,
  AnimatePresence,
  useMotionValue,
  useTransform,
  animate,
  useInView,
} from "framer-motion";
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import {
  Wallet,
  Coffee,
  ShoppingBag,
  Pizza,
  Moon,
  PiggyBank,
  ChevronDown,
  Search,
  Sparkles,
  Trophy,
  Ghost,
  Target,
  Flame,
  Calculator,
  Quote,
  Share2,
  Menu,
  X,
  Check,
  ArrowRight,
} from "lucide-react";

export const Route = createFileRoute("/")({
  component: Index,
});

/* ---------------- Floating Background ---------------- */
const MONEY_EMOJIS = ["💸", "💰", "🪙", "💵", "🤑", "🧾", "💳", "🏦", "₹"];

function FloatingBackground() {
  const [mounted, setMounted] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  useEffect(() => {
    setMounted(true);
    const update = () => setIsMobile(window.innerWidth < 768);
    update();
    window.addEventListener("resize", update);
    return () => window.removeEventListener("resize", update);
  }, []);

  const count = isMobile ? 6 : 14;
  const symbols = useMemo(
    () =>
      Array.from({ length: count }).map((_, i) => ({
        id: i,
        left: Math.random() * 95,
        top: Math.random() * 95,
        size: 22 + Math.random() * 36,
        delay: Math.random() * 4,
        duration: 7 + Math.random() * 7,
        rotate: Math.random() * 40 - 20,
        emoji: MONEY_EMOJIS[i % MONEY_EMOJIS.length],
        spin: Math.random() > 0.6,
      })),
    [count],
  );

  const blobs = [
    { color: "var(--accent-yellow)", size: 420, left: "-6%", top: "8%" },
    { color: "var(--accent-blue)", size: 320, left: "72%", top: "38%" },
    { color: "var(--accent-purple)", size: 280, left: "28%", top: "72%" },
    { color: "var(--accent-green)", size: 240, left: "60%", top: "82%" },
  ];

  if (!mounted) return null;

  return (
    <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
      {/* soft dotted grid */}
      <div
        className="absolute inset-0 opacity-[0.35]"
        style={{
          backgroundImage:
            "radial-gradient(circle, rgba(17,17,17,0.07) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />
      {blobs.map((b, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full blur-3xl"
          style={{
            background: b.color,
            width: b.size,
            height: b.size,
            left: b.left,
            top: b.top,
            opacity: 0.35,
            willChange: "transform",
          }}
          animate={{ x: [0, 40, 0], y: [0, -20, 0] }}
          transition={{ duration: 18 + i * 4, repeat: Infinity, ease: "easeInOut" }}
        />
      ))}
      {symbols.map((s) => (
        <motion.div
          key={s.id}
          className="absolute select-none"
          style={{
            left: `${s.left}%`,
            top: `${s.top}%`,
            fontSize: s.size,
            opacity: 0.22,
            willChange: "transform",
            filter: "drop-shadow(0 6px 12px rgba(17,17,17,0.08))",
          }}
          animate={
            s.spin
              ? { y: [-14, 14, -14], rotate: [0, 360] }
              : { y: [-14, 14, -14], rotate: [s.rotate, -s.rotate, s.rotate] }
          }
          transition={{
            duration: s.duration,
            repeat: Infinity,
            ease: "easeInOut",
            delay: s.delay,
          }}
        >
          {s.emoji}
        </motion.div>
      ))}
    </div>
  );
}

/* ---------------- Money Rain (decorative) ---------------- */
function MoneyRain({ count = 18, zIndex = 1 }: { count?: number; zIndex?: number }) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  const drops = useMemo(
    () =>
      Array.from({ length: count }).map((_, i) => ({
        id: i,
        left: Math.random() * 100,
        size: 18 + Math.random() * 22,
        delay: Math.random() * 5,
        duration: 6 + Math.random() * 5,
        rotate: Math.random() * 60 - 30,
        emoji: ["💵", "💸", "🪙", "💰"][i % 4],
      })),
    [count],
  );
  if (!mounted) return null;
  return (
    <div
      className="pointer-events-none absolute inset-0 overflow-hidden"
      style={{ zIndex }}
    >
      {drops.map((d) => (
        <motion.div
          key={d.id}
          className="absolute select-none"
          style={{
            left: `${d.left}%`,
            top: "-10%",
            fontSize: d.size,
            opacity: 0.55,
            willChange: "transform",
          }}
          initial={{ y: "-10vh", rotate: d.rotate }}
          animate={{ y: "110vh", rotate: d.rotate + 360 }}
          transition={{
            duration: d.duration,
            delay: d.delay,
            repeat: Infinity,
            ease: "linear",
          }}
        >
          {d.emoji}
        </motion.div>
      ))}
    </div>
  );
}

/* ---------------- Intro Splash ---------------- */
function IntroSplash({ onDone }: { onDone: () => void }) {
  useEffect(() => {
    const t = setTimeout(onDone, 2800);
    return () => clearTimeout(t);
  }, [onDone]);

  const letters = "BROKECHECK".split("");

  return (
    <motion.div
      key="splash"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, y: -40, transition: { duration: 0.7, ease: [0.7, 0, 0.3, 1] } }}
      className="fixed inset-0 z-[100] flex items-center justify-center overflow-hidden"
      style={{
        background:
          "radial-gradient(ellipse at 50% 30%, #fff7c2 0%, #fde68a 35%, #f59e0b 100%)",
      }}
    >
      {/* heavy money rain */}
      <MoneyRain count={28} zIndex={1} />

      {/* spinning huge coin behind */}
      <motion.div
        initial={{ scale: 0.4, opacity: 0 }}
        animate={{ scale: 1, opacity: 0.18, rotate: 360 }}
        transition={{
          scale: { duration: 0.9, ease: "easeOut" },
          opacity: { duration: 0.9 },
          rotate: { duration: 6, repeat: Infinity, ease: "linear" },
        }}
        className="absolute select-none"
        style={{ fontSize: "min(70vw, 560px)" }}
      >
        🪙
      </motion.div>

      <div className="relative z-10 text-center">
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1, duration: 0.5 }}
          className="mb-5 inline-flex items-center gap-2 rounded-full border border-black/10 bg-white/70 px-4 py-1.5 text-[11px] font-bold uppercase tracking-[0.22em] text-black/70 backdrop-blur"
        >
          <span className="inline-flex h-1.5 w-1.5 animate-pulse rounded-full bg-red-500" />
          Loading your damage report
        </motion.div>

        <div className="flex items-center justify-center gap-1 px-4">
          {letters.map((ch, i) => (
            <motion.span
              key={i}
              initial={{ y: 80, opacity: 0, rotate: -8 }}
              animate={{ y: 0, opacity: 1, rotate: 0 }}
              transition={{
                delay: 0.2 + i * 0.05,
                duration: 0.6,
                ease: [0.22, 1, 0.36, 1],
              }}
              className="font-display text-[14vw] font-black leading-none tracking-[-0.04em] text-black sm:text-[88px]"
              style={{ textShadow: "0 4px 0 rgba(0,0,0,0.08)" }}
            >
              {ch}
            </motion.span>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.9, duration: 0.4 }}
          className="mt-4 flex items-center justify-center gap-2 text-sm font-semibold text-black/70"
        >
          <motion.span
            animate={{ rotate: [0, 20, -20, 0] }}
            transition={{ duration: 1.2, repeat: Infinity }}
            className="text-xl"
          >
            💸
          </motion.span>
          counting how broke you are…
          <motion.span
            animate={{ rotate: [0, -20, 20, 0] }}
            transition={{ duration: 1.2, repeat: Infinity }}
            className="text-xl"
          >
            🤑
          </motion.span>
        </motion.div>

        {/* progress bar */}
        <div className="mx-auto mt-7 h-1.5 w-56 overflow-hidden rounded-full bg-black/10">
          <motion.div
            initial={{ width: "0%" }}
            animate={{ width: "100%" }}
            transition={{ duration: 2.3, ease: "easeInOut" }}
            className="h-full rounded-full bg-black"
          />
        </div>
      </div>
    </motion.div>
  );
}


/* ---------------- Navbar ---------------- */
function Navbar() {
  const [open, setOpen] = useState(false);
  const [hovered, setHovered] = useState<string | null>(null);
  const links = [
    { label: "Home", href: "#home" },
    { label: "Calculator", href: "#calculator" },
    { label: "Roast", href: "#roast" },
    { label: "About", href: "#about" },
  ];
  const scrollTo = (href: string) => {
    setOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };
  return (
    <header className="sticky top-0 z-50 border-b border-border bg-white/80 backdrop-blur-md">
      <nav className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
        <a href="#home" className="font-display text-xl font-black tracking-tight">
          💸 BrokeCheck
        </a>
        <div
          className="hidden items-center gap-1 md:flex"
          onMouseLeave={() => setHovered(null)}
        >
          {links.map((l) => (
            <button
              key={l.label}
              onMouseEnter={() => setHovered(l.label)}
              onClick={() => scrollTo(l.href)}
              className="relative px-4 py-2 text-sm font-medium text-foreground/80 transition hover:text-foreground"
            >
              {l.label}
              {hovered === l.label && (
                <motion.span
                  layoutId="navunderline"
                  className="absolute inset-x-3 -bottom-0.5 h-0.5 rounded-full bg-foreground"
                  transition={{ type: "spring", stiffness: 380, damping: 30 }}
                />
              )}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => scrollTo("#calculator")}
            className="hidden rounded-full bg-foreground px-5 py-2.5 text-sm font-semibold text-primary-foreground shadow-sm transition hover:scale-[1.03] hover:shadow-md md:inline-flex"
          >
            Check My Wallet
          </button>
          <button
            onClick={() => setOpen((v) => !v)}
            className="rounded-full border border-border bg-white p-2 md:hidden"
            aria-label="Menu"
          >
            {open ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </nav>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden border-t border-border bg-white md:hidden"
          >
            <div className="flex flex-col px-4 py-3">
              {links.map((l) => (
                <button
                  key={l.label}
                  onClick={() => scrollTo(l.href)}
                  className="rounded-lg px-3 py-3 text-left text-base font-medium hover:bg-muted"
                >
                  {l.label}
                </button>
              ))}
              <button
                onClick={() => scrollTo("#calculator")}
                className="mt-2 rounded-full bg-foreground px-5 py-3 text-sm font-semibold text-primary-foreground"
              >
                Check My Wallet
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

/* ---------------- Animated Number ---------------- */
function AnimatedNumber({
  value,
  duration = 1.5,
  prefix = "",
  suffix = "",
}: {
  value: number;
  duration?: number;
  prefix?: string;
  suffix?: string;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-50px" });
  const mv = useMotionValue(0);
  const rounded = useTransform(mv, (v) => Math.round(v).toLocaleString("en-IN"));
  useEffect(() => {
    if (inView) {
      const controls = animate(mv, value, { duration, ease: "easeOut" });
      return controls.stop;
    }
  }, [inView, value, duration, mv]);
  return (
    <span ref={ref} className="tnum">
      {prefix}
      <motion.span>{rounded}</motion.span>
      {suffix}
    </span>
  );
}

/* ---------------- Hero ---------------- */
function HeroSection() {
  const words = ["How", "Broke", "Are", "You,", "Really?"];
  return (
    <section
      id="home"
      className="relative flex min-h-[92vh] items-center overflow-hidden px-4 py-16 sm:px-6 sm:py-20"
    >
      <MoneyRain count={10} zIndex={0} />
      <div className="relative z-10 mx-auto grid max-w-6xl items-center gap-12 lg:grid-cols-[1.1fr_0.9fr]">
        <div>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-white/80 px-3 py-1.5 text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground shadow-[0_1px_0_rgba(255,255,255,0.9)_inset,0_1px_2px_rgba(17,17,17,0.04)] backdrop-blur"
          >
            <span className="inline-flex h-1.5 w-1.5 rounded-full bg-[#22c55e] shadow-[0_0_0_3px_rgba(34,197,94,0.18)]" />
            A financial roast machine
          </motion.div>
          <h1 className="font-display text-[44px] font-black leading-[0.95] tracking-[-0.035em] sm:text-6xl lg:text-[80px]">
            {words.map((w, i) => (
              <motion.span
                key={i}
                initial={{ opacity: 0, y: 24 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 + i * 0.08, duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
                className="mr-3 inline-block"
              >
                {w}
              </motion.span>
            ))}
          </h1>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.7, duration: 0.6 }}
            className="mt-6 max-w-md text-base leading-relaxed text-[#555] sm:text-[17px]"
          >
            A scientifically unnecessary financial analysis for students who buy coffee
            instead of groceries.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.85, duration: 0.5 }}
            className="mt-8 flex flex-wrap items-center gap-4"
          >
            <button
              onClick={() =>
                document.querySelector("#calculator")?.scrollIntoView({ behavior: "smooth" })
              }
              className="group inline-flex items-center gap-2 rounded-full bg-foreground px-7 py-3.5 text-[15px] font-semibold text-primary-foreground shadow-[0_1px_0_rgba(255,255,255,0.18)_inset,0_1px_2px_rgba(17,17,17,0.18),0_10px_24px_-10px_rgba(17,17,17,0.45)] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_1px_0_rgba(255,255,255,0.22)_inset,0_2px_4px_rgba(17,17,17,0.22),0_20px_40px_-12px_rgba(17,17,17,0.5)]"
            >
              Analyze My Wallet
              <ArrowRight size={17} className="transition-transform duration-300 group-hover:translate-x-1" />
            </button>
            <span className="text-sm text-muted-foreground">Free. No login. Pure pain.</span>
          </motion.div>
        </div>

        {/* Demo card */}
        <motion.div
          initial={{ opacity: 0, y: 30, rotate: -1 }}
          animate={{ opacity: 1, y: 0, rotate: -1 }}
          whileHover={{ rotate: 0, y: -4 }}
          transition={{ delay: 0.4, duration: 0.7, ease: "easeOut" }}
          className="mx-auto w-full max-w-sm rounded-3xl border border-border bg-white/70 p-6 shadow-[0_20px_60px_-20px_rgba(0,0,0,0.18)] backdrop-blur-md"
        >
          <div className="mb-4 flex items-center justify-between">
            <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Live damage report
            </div>
            <div className="h-2 w-2 animate-pulse rounded-full bg-red-400" />
          </div>
          <div className="space-y-3">
            {[
              {
                value: 2340,
                prefix: "₹",
                label: "spent on snacks this month",
                emoji: "🍕",
                bg: "var(--accent-yellow)",
              },
              {
                value: 84,
                suffix: "%",
                label: "of salary vanished mysteriously",
                emoji: "💨",
                bg: "var(--accent-red)",
              },
              {
                value: 0,
                label: "days of financial stability left",
                emoji: "📉",
                bg: "var(--accent-blue)",
              },
            ].map((s, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.7 + i * 0.15, duration: 0.5 }}
                className="flex items-center gap-4 rounded-2xl p-4"
                style={{ background: s.bg }}
              >
                <div className="text-2xl">{s.emoji}</div>
                <div className="min-w-0 flex-1">
                  <div className="font-display text-2xl font-black leading-none">
                    <AnimatedNumber
                      value={s.value}
                      prefix={s.prefix}
                      suffix={s.suffix}
                      duration={1.4}
                    />
                  </div>
                  <div className="mt-1 text-xs text-[#555]">{s.label}</div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      <motion.div
        animate={{ y: [0, 8, 0] }}
        transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
        className="pointer-events-none absolute bottom-6 left-1/2 -translate-x-1/2 text-muted-foreground"
      >
        <ChevronDown size={26} />
      </motion.div>
    </section>
  );
}

/* ---------------- How It Works ---------------- */
function HowItWorksSection() {
  const steps = [
    { n: "01", title: "Tell us your sins", desc: "Confess your monthly spending without crying.", Icon: Calculator },
    { n: "02", title: "We do the math", desc: "Our highly unscientific algorithm crunches the damage.", Icon: Sparkles },
    { n: "03", title: "We roast you kindly", desc: "Gentle, hilarious, slightly devastating verdict.", Icon: Flame },
  ];
  return (
    <section className="relative px-4 py-16 sm:px-6 sm:py-20">
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="How it works"
          title="Three steps to financial enlightenment"
          subtitle="(Or financial despair. Same thing, really.)"
        />
        <div className="mt-12 grid gap-5 md:grid-cols-3">
          {steps.map((s, i) => (
            <motion.div
              key={s.n}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0, margin: "0px 0px -10% 0px" }}
              transition={{ delay: i * 0.1, duration: 0.5 }}
              whileHover={{ y: -4 }}
              className="relative overflow-hidden rounded-3xl border border-border bg-white p-7 shadow-[0_1px_0_rgba(255,255,255,0.9)_inset,0_1px_2px_rgba(17,17,17,0.04),0_12px_30px_-18px_rgba(17,17,17,0.12)] transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_24px_50px_-22px_rgba(17,17,17,0.18)]"
            >
              <div className="pointer-events-none absolute -right-2 -top-6 font-display text-8xl font-black text-[#F0F0F0]">
                {s.n}
              </div>
              <div className="relative">
                <div className="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-[var(--accent-purple)] text-foreground">
                  <s.Icon size={20} />
                </div>
                <h3 className="font-display text-xl font-semibold">{s.title}</h3>
                <p className="mt-2 text-sm text-[#555]">{s.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function SectionHeading({
  eyebrow,
  title,
  subtitle,
}: {
  eyebrow: string;
  title: string;
  subtitle?: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0, margin: "0px 0px -10% 0px" }}
      transition={{ duration: 0.5 }}
      className="text-center"
    >
      <div className="mb-3 text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">
        {eyebrow}
      </div>
      <h2 className="font-display text-3xl font-bold tracking-tight sm:text-4xl">{title}</h2>
      {subtitle && <p className="mt-3 text-base text-[#555]">{subtitle}</p>}
    </motion.div>
  );
}

/* ---------------- Calculator ---------------- */
type Inputs = {
  income: string;
  food: string;
  coffee: string;
  shopping: string;
  impulse: string;
  savings: string;
};

const FIELDS: {
  key: keyof Inputs;
  label: string;
  placeholder: string;
  accent: string;
  Icon: any;
}[] = [
  { key: "income", label: "Monthly Allowance / Income", placeholder: "e.g. ₹15,000", accent: "var(--accent-blue)", Icon: Wallet },
  { key: "food", label: "Swiggy / Zomato Spending", placeholder: "e.g. ₹3,000", accent: "var(--accent-yellow)", Icon: Pizza },
  { key: "coffee", label: "Coffee & Café Runs", placeholder: "e.g. ₹800", accent: "var(--accent-yellow)", Icon: Coffee },
  { key: "shopping", label: "Online Shopping", placeholder: "e.g. ₹2,000", accent: "var(--accent-red)", Icon: ShoppingBag },
  { key: "impulse", label: "Late-night Impulse Purchases", placeholder: "e.g. ₹1,200", accent: "var(--accent-red)", Icon: Moon },
  { key: "savings", label: "Actual Savings", placeholder: "e.g. ₹500", accent: "var(--accent-green)", Icon: PiggyBank },
];

function FloatingInput({
  field,
  value,
  onChange,
}: {
  field: (typeof FIELDS)[number];
  value: string;
  onChange: (v: string) => void;
}) {
  const [focused, setFocused] = useState(false);
  const filled = value.length > 0;
  return (
    <label className="relative block">
      <div
        className="absolute left-3 top-1/2 z-10 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-lg"
        style={{ background: field.accent }}
      >
        <field.Icon size={16} />
      </div>
      <motion.span
        animate={{
          y: focused || filled ? -10 : 12,
          scale: focused || filled ? 0.82 : 1,
          color: focused ? "#111" : "#888",
        }}
        transition={{ type: "spring", stiffness: 400, damping: 30 }}
        className="pointer-events-none absolute left-14 top-2 origin-left text-sm font-medium"
      >
        {field.label}
      </motion.span>
      <input
        inputMode="numeric"
        value={value}
        onChange={(e) => onChange(e.target.value.replace(/[^\d]/g, ""))}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        placeholder={focused ? field.placeholder : ""}
        className="h-[68px] w-full rounded-2xl border border-border bg-white pl-14 pr-4 pt-5 pb-1 text-base font-semibold text-foreground outline-none transition focus:border-foreground focus:ring-2 focus:ring-black/10"
      />
    </label>
  );
}

/* ---------------- Typewriter ---------------- */
function useTypewriter(text: string, speed = 22, start = true) {
  const [out, setOut] = useState("");
  useEffect(() => {
    if (!start) {
      setOut("");
      return;
    }
    let i = 0;
    setOut("");
    const id = setInterval(() => {
      i++;
      setOut(text.slice(0, i));
      if (i >= text.length) clearInterval(id);
    }, speed);
    return () => clearInterval(id);
  }, [text, speed, start]);
  return out;
}

function TypewriterLine({ text, delay, onDone }: { text: string; delay: number; onDone?: () => void }) {
  const [start, setStart] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setStart(true), delay);
    return () => clearTimeout(t);
  }, [delay]);
  const out = useTypewriter(text, 18, start);
  const done = out.length === text.length && start;
  useEffect(() => {
    if (done && onDone) onDone();
  }, [done, onDone]);
  return (
    <div className="flex items-center justify-between gap-4 font-mono text-sm sm:text-base">
      <span className="text-foreground">{out}<span className="opacity-40">{!done && start ? "▍" : ""}</span></span>
      <AnimatePresence>
        {done && (
          <motion.span
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="flex h-5 w-5 items-center justify-center rounded-full bg-[var(--accent-green)] text-foreground"
          >
            <Check size={12} strokeWidth={3} />
          </motion.span>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ---------------- Results ---------------- */
type Computed = {
  income: number;
  food: number;
  coffee: number;
  shopping: number;
  impulse: number;
  savings: number;
  totalSpend: number;
  brokeScore: number;
  daysToExtinction: number;
  personality: { name: string; emoji: string; descriptor: string };
  roast: string;
  memes: string[];
};

function computeResults(i: Inputs): Computed {
  const income = Math.max(1, Number(i.income) || 0);
  const food = Number(i.food) || 0;
  const coffee = Number(i.coffee) || 0;
  const shopping = Number(i.shopping) || 0;
  const impulse = Number(i.impulse) || 0;
  const savings = Number(i.savings) || 0;
  const totalSpend = food + coffee + shopping + impulse;
  const brokeScore = Math.min(100, Math.round((totalSpend / income) * 100));
  const daysToExtinction =
    totalSpend > 0 ? Math.max(0, Math.round(savings / (totalSpend / 30))) : 999;

  const foodPct = (food / income) * 100;
  const coffeePct = (coffee / income) * 100;
  const impulsePct = (impulse / income) * 100;
  const savingsPct = (savings / income) * 100;

  let personality = { name: "Broke but Stylish", emoji: "✨", descriptor: "Vibes over balances. Always." };
  if (impulsePct > 30) personality = { name: "Midnight Shopper", emoji: "🌙", descriptor: "Your cart fills up after midnight." };
  else if (foodPct > 35) personality = { name: "Swiggy Dependent", emoji: "🍔", descriptor: "Delivery apps know your home better than you." };
  else if (coffeePct > 15) personality = { name: "Coffee Investor", emoji: "☕", descriptor: "Equity in cafés, debt in life." };
  else if (savingsPct > 30) personality = { name: "Suspiciously Responsible", emoji: "👀", descriptor: "Are you okay? Genuinely." };
  if (foodPct > 35 && impulsePct > 30 && coffeePct > 15)
    personality = { name: "Budget Destroyer", emoji: "💣", descriptor: "Walking financial natural disaster." };

  let roast = "You're actually okay. Suspicious.";
  if (brokeScore >= 90) roast = "Your bank account has separation anxiety from zero.";
  else if (brokeScore >= 80) roast = "Your money leaves faster than your situationship.";
  else if (brokeScore >= 70) roast = "You budget like it's a suggestion, not a rule.";
  else if (brokeScore >= 60) roast = "Financially, you're vibing. Dangerously.";

  const memes: string[] = [];
  if (food > coffee && food > impulse) memes.push("You spent more on Swiggy than on your future.");
  if (coffee > 800) memes.push("Your coffee budget could fund a small startup.");
  if (savings < income * 0.05) memes.push("Savings: exists but make it fashion.");
  if (impulse > 1500) memes.push("Your 2 AM cart is a national security threat.");
  if (shopping > income * 0.2) memes.push("Your wardrobe has better assets than your portfolio.");
  while (memes.length < 3) memes.push("You're built different. Financially concerning, but different.");

  return {
    income, food, coffee, shopping, impulse, savings,
    totalSpend, brokeScore, daysToExtinction,
    personality, roast, memes: memes.slice(0, 3),
  };
}

function brokeScoreTheme(score: number) {
  if (score <= 40) return { bg: "var(--accent-green)", label: "Surprisingly Functional" };
  if (score <= 70) return { bg: "var(--accent-yellow)", label: "Living Dangerously" };
  return { bg: "var(--accent-red)", label: "Financially Deceased" };
}

function ResultsSection({ data }: { data: Computed }) {
  const theme = brokeScoreTheme(data.brokeScore);
  const pieData = [
    { name: "Food", value: data.food, fill: "#FFE7A8" },
    { name: "Coffee", value: data.coffee, fill: "#F7D08A" },
    { name: "Shopping", value: data.shopping, fill: "#FFB3B3" },
    { name: "Impulse", value: data.impulse, fill: "#FF8E8E" },
    { name: "Savings", value: data.savings, fill: "#A8E6B6" },
  ].filter((d) => d.value > 0);

  const survivalBg =
    data.daysToExtinction < 15
      ? "var(--accent-red)"
      : data.daysToExtinction < 30
      ? "var(--accent-yellow)"
      : "var(--accent-green)";

  const [copied, setCopied] = useState(false);
  const copyRoast = async () => {
    await navigator.clipboard.writeText(`"${data.roast}" — BrokeCheck`);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  const cardCls =
    "rounded-3xl border border-border bg-white p-6 shadow-[0_1px_0_rgba(255,255,255,0.9)_inset,0_1px_2px_rgba(17,17,17,0.04),0_12px_30px_-18px_rgba(17,17,17,0.12)] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_1px_0_rgba(255,255,255,0.9)_inset,0_2px_4px_rgba(17,17,17,0.05),0_24px_50px_-22px_rgba(17,17,17,0.18)]";

  return (
    <motion.section
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.4 }}
      className="relative px-4 py-12 sm:px-6 sm:py-16"
    >
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="Your verdict"
          title="The financial damage report"
          subtitle="Brought to you by zero financial credentials whatsoever."
        />
        <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {/* Card 1 — Broke Score */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 }}
            className={cardCls}
            style={{ background: theme.bg }}
          >
            <div className="text-xs font-semibold uppercase tracking-wider text-foreground/60">
              Broke Score
            </div>
            <div className="mt-4 text-center">
              <div className="font-display text-7xl font-black leading-none">
                <AnimatedNumber value={data.brokeScore} suffix="%" duration={1.8} />
              </div>
              <div className="mt-3 font-display text-lg font-semibold">{theme.label}</div>
            </div>
          </motion.div>

          {/* Card 2 — Personality */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className={cardCls}
            style={{ background: "var(--accent-purple)" }}
          >
            <div className="text-xs font-semibold uppercase tracking-wider text-foreground/60">
              Financial Personality
            </div>
            <div className="mt-4 flex items-center gap-3">
              <div className="text-4xl">{data.personality.emoji}</div>
              <div>
                <div className="font-display text-2xl font-bold leading-tight">
                  {data.personality.name}
                </div>
                <div className="text-sm text-[#555]">{data.personality.descriptor}</div>
              </div>
            </div>
          </motion.div>

          {/* Card 3 — Roast */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
            className={cardCls}
            style={{ background: "var(--accent-yellow)" }}
          >
            <div className="flex items-start justify-between">
              <div className="text-xs font-semibold uppercase tracking-wider text-foreground/60">
                The Roast
              </div>
              <Quote size={36} className="-mt-2 text-foreground/20" />
            </div>
            <p className="mt-2 font-display text-lg font-semibold italic leading-snug">
              "{data.roast}"
            </p>
            <button
              onClick={copyRoast}
              className="mt-4 inline-flex items-center gap-2 rounded-full bg-foreground px-4 py-2 text-xs font-semibold text-primary-foreground transition hover:scale-[1.03]"
            >
              <Share2 size={14} /> {copied ? "Copied!" : "Share Roast"}
            </button>
          </motion.div>

          {/* Card 4 — Health Meter */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className={cardCls + " md:col-span-2"}
          >
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Financial Health
                </div>
                <div className="mt-1 font-display text-lg font-semibold">
                  {100 - data.brokeScore < 30
                    ? "Critical condition"
                    : 100 - data.brokeScore < 60
                    ? "Stable but fragile"
                    : "Surprisingly fine"}
                </div>
              </div>
              <div className="font-display text-3xl font-black">
                <AnimatedNumber value={100 - data.brokeScore} suffix="%" duration={1.6} />
              </div>
            </div>
            <div className="mt-5 h-3 w-full overflow-hidden rounded-full bg-muted">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${100 - data.brokeScore}%` }}
                transition={{ duration: 1.4, ease: "easeOut" }}
                className="h-full rounded-full"
                style={{ background: theme.bg, filter: "saturate(1.4) brightness(0.92)" }}
              />
            </div>
          </motion.div>

          {/* Card 5 — Pie */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.25 }}
            className={cardCls}
          >
            <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Where your money went
            </div>
            <div className="h-44">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    dataKey="value"
                    nameKey="name"
                    innerRadius={40}
                    outerRadius={70}
                    paddingAngle={2}
                    stroke="none"
                  >
                    {pieData.map((d, i) => (
                      <Cell key={i} fill={d.fill} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      borderRadius: 12,
                      border: "1px solid #ECECEC",
                      fontSize: 12,
                    }}
                    formatter={(v: number) => `₹${v.toLocaleString("en-IN")}`}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-2 flex flex-wrap justify-center gap-1.5">
              {pieData.map((d) => (
                <span
                  key={d.name}
                  className="inline-flex items-center gap-1.5 rounded-full border border-border bg-white px-2.5 py-1 text-xs font-medium"
                >
                  <span
                    className="h-2 w-2 rounded-full"
                    style={{ background: d.fill }}
                  />
                  {d.name}
                </span>
              ))}
            </div>
          </motion.div>

          {/* Card 6 — Survival */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className={cardCls}
            style={{ background: survivalBg }}
          >
            <div className="text-xs font-semibold uppercase tracking-wider text-foreground/60">
              ⏳ Days Until Financial Extinction
            </div>
            <div className="mt-4 font-display text-6xl font-black leading-none">
              <AnimatedNumber
                value={data.daysToExtinction > 999 ? 999 : data.daysToExtinction}
                duration={1.6}
              />
            </div>
            <p className="mt-3 text-sm text-[#444]">
              {data.daysToExtinction < 15
                ? `Your bank account has approximately ${data.daysToExtinction} days before it enters the afterlife.`
                : data.daysToExtinction < 30
                ? "You'll survive the month. Probably. Maybe."
                : "You're playing the long game. Respect."}
            </p>
          </motion.div>

          {/* Card 7 — Memes */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.35 }}
            className={cardCls + " md:col-span-2 lg:col-span-3"}
          >
            <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Meme Analysis
            </div>
            <ul className="mt-4 grid gap-3 sm:grid-cols-3">
              {data.memes.map((m, i) => (
                <motion.li
                  key={i}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 + i * 0.1 }}
                  className="rounded-2xl border border-border bg-muted/40 p-4 font-display text-base font-semibold"
                >
                  "{m}"
                </motion.li>
              ))}
            </ul>
          </motion.div>
        </div>
      </div>
    </motion.section>
  );
}

/* ---------------- Badges ---------------- */
function BadgesSection({ data }: { data: Computed | null }) {
  const badges = [
    { name: "CEO of Bad Decisions", emoji: "🏆", cond: "Impulse > ₹2,000", unlocked: !!data && data.impulse > 2000 },
    { name: "Coffee Investor", emoji: "☕", cond: "Coffee > ₹1,000", unlocked: !!data && data.coffee > 1000 },
    { name: "Swiggy Shareholder", emoji: "📦", cond: "Food > ₹4,000", unlocked: !!data && data.food > 4000 },
    { name: "Ghost Saver", emoji: "👻", cond: "Savings < ₹100", unlocked: !!data && data.savings < 100 },
    { name: "Impulse Buying Champion", emoji: "🎯", cond: "Impulse > ₹3,000", unlocked: !!data && data.impulse > 3000 },
    { name: "Rich for 2 Days", emoji: "💅", cond: "Income > ₹20k & broke", unlocked: !!data && data.income > 20000 && data.brokeScore > 80 },
    { name: "Financially Enlightened", emoji: "🧘", cond: "Broke score < 30%", unlocked: !!data && data.brokeScore < 30 },
  ];
  return (
    <section className="relative px-4 py-16 sm:px-6 sm:py-20">
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="Achievements"
          title="Achievements Unlocked"
          subtitle="Wear your financial chaos with pride."
        />
        <div className="mt-10 flex gap-4 overflow-x-auto pb-4 md:grid md:grid-cols-3 md:overflow-visible md:pb-0 lg:grid-cols-4">
          {badges.map((b, i) => (
            <motion.div
              key={b.name}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true, amount: 0, margin: "0px 0px -10% 0px" }}
              transition={{
                delay: i * 0.05,
                type: "spring",
                stiffness: 300,
                damping: 18,
              }}
              className={`min-w-[220px] rounded-3xl border border-border bg-white p-5 text-center shadow-[0_1px_0_rgba(255,255,255,0.9)_inset,0_1px_2px_rgba(17,17,17,0.04),0_12px_30px_-18px_rgba(17,17,17,0.12)] transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_24px_50px_-22px_rgba(17,17,17,0.18)] ${
                b.unlocked ? "" : "opacity-40 grayscale"
              }`}
            >
              <div className="text-4xl">{b.emoji}</div>
              <div className="mt-2 font-display text-base font-bold">{b.name}</div>
              <div className="mt-1 text-xs text-muted-foreground">{b.cond}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Roast Generator ---------------- */
const ROAST_POOL = [
  "Your bank account has separation anxiety from zero.",
  "Your money leaves faster than your situationship.",
  "You budget like it's a suggestion, not a rule.",
  "Financially, you're vibing. Dangerously.",
  "Your savings account is technically a tip jar.",
  "You treat your salary like a 7-day Netflix trial.",
  "Your coffee receipts could file taxes by themselves.",
  "The only thing growing in your account is dust.",
  "You shop online to feel emotions. It works.",
  "Your impulse purchases have impulse purchases.",
  "RBI checks YOUR account for entertainment.",
  "Your wallet has trust issues. Earned them.",
  "You're one Zomato order from a TED talk on regret.",
  "Your savings are theoretical, like work-life balance.",
  "Your money speedruns your account. World record holder.",
  "You buy things to cope with buying things.",
  "Your portfolio is just screenshots of Swiggy receipts.",
  "Compounding interest fled from you in fear.",
  "You're not broke, you're 'pre-rich'. (You're broke.)",
  "Your account balance is in a long-distance relationship with you.",
];

function RoastGeneratorSection() {
  const [idx, setIdx] = useState(0);
  const [key, setKey] = useState(0);
  const [toast, setToast] = useState(false);
  const current = ROAST_POOL[idx];
  const text = useTypewriter(current, 18, true);

  const next = () => {
    let n = idx;
    while (n === idx) n = Math.floor(Math.random() * ROAST_POOL.length);
    setIdx(n);
    setKey((k) => k + 1);
  };
  const share = async () => {
    await navigator.clipboard.writeText(`"${current}" — BrokeCheck`);
    setToast(true);
    setTimeout(() => setToast(false), 1800);
  };

  return (
    <section id="roast" className="relative px-4 py-16 sm:px-6 sm:py-20">
      <div className="mx-auto max-w-3xl">
        <SectionHeading
          eyebrow="Roast generator"
          title="Need another wound?"
          subtitle="One button. Infinite financial humbling."
        />
        <motion.div
          key={key}
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-10 rounded-3xl border border-border bg-white p-8 shadow-[0_1px_0_rgba(255,255,255,0.9)_inset,0_1px_2px_rgba(17,17,17,0.04),0_24px_60px_-30px_rgba(17,17,17,0.18)] sm:p-10"
        >
          <Quote size={36} className="text-foreground/15" />
          <p className="mt-3 min-h-[80px] font-display text-2xl font-bold leading-snug italic sm:text-3xl">
            "{text}"
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <button
              onClick={next}
              className="inline-flex items-center gap-2 rounded-full bg-foreground px-6 py-3 text-sm font-semibold text-primary-foreground transition hover:scale-[1.03] hover:shadow-lg"
            >
              <Sparkles size={16} /> Generate New Roast
            </button>
            <button
              onClick={share}
              className="inline-flex items-center gap-2 rounded-full border border-border bg-white px-6 py-3 text-sm font-semibold transition hover:bg-muted"
            >
              <Share2 size={16} /> Share
            </button>
          </div>
        </motion.div>
      </div>
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ y: 40, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 40, opacity: 0 }}
            className="fixed bottom-6 left-1/2 z-50 -translate-x-1/2 rounded-full bg-foreground px-5 py-3 text-sm font-semibold text-primary-foreground shadow-xl"
          >
            Copied! 🎉
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}

/* ---------------- Calculator Section ---------------- */
function CalculatorSection({
  onSubmit,
}: {
  onSubmit: (data: Computed) => void;
}) {
  const [values, setValues] = useState<Inputs>({
    income: "", food: "", coffee: "", shopping: "", impulse: "", savings: "",
  });
  const [analyzing, setAnalyzing] = useState(false);
  const [doneSteps, setDoneSteps] = useState(0);

  const totalSpend =
    (Number(values.food) || 0) +
    (Number(values.coffee) || 0) +
    (Number(values.shopping) || 0) +
    (Number(values.impulse) || 0);

  const canSubmit = Number(values.income) > 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canSubmit) return;
    setAnalyzing(true);
    setDoneSteps(0);
  };

  useEffect(() => {
    if (analyzing && doneSteps >= 4) {
      const t = setTimeout(() => {
        onSubmit(computeResults(values));
        setAnalyzing(false);
      }, 500);
      return () => clearTimeout(t);
    }
  }, [analyzing, doneSteps, values, onSubmit]);

  return (
    <section id="calculator" className="relative px-4 py-16 sm:px-6 sm:py-20">
      <div className="mx-auto max-w-3xl">
        <SectionHeading
          eyebrow="The damage"
          title="Confess Your Spending"
          subtitle="We promise not to judge. (We totally will.)"
        />
        <form
          onSubmit={handleSubmit}
          className="mt-10 rounded-[28px] border border-border bg-white p-6 shadow-[0_1px_0_rgba(255,255,255,0.9)_inset,0_1px_2px_rgba(17,17,17,0.04),0_30px_70px_-30px_rgba(17,17,17,0.18)] sm:p-8"
        >
          <div className="grid gap-4 sm:grid-cols-2">
            {FIELDS.map((f) => (
              <FloatingInput
                key={f.key}
                field={f}
                value={values[f.key]}
                onChange={(v) => setValues((s) => ({ ...s, [f.key]: v }))}
              />
            ))}
          </div>
          <div className="mt-6 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-border bg-[var(--accent-green)]/40 p-4">
            <span className="text-xs font-semibold uppercase tracking-[0.18em] text-foreground/60">
              Total tracked spending
            </span>
            <span className="font-display text-2xl font-black tnum">
              ₹{totalSpend.toLocaleString("en-IN")}
            </span>
          </div>
          <button
            type="submit"
            disabled={!canSubmit || analyzing}
            className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-full bg-foreground px-8 py-4 text-base font-semibold text-primary-foreground shadow-[0_1px_0_rgba(255,255,255,0.18)_inset,0_1px_2px_rgba(17,17,17,0.18),0_14px_30px_-12px_rgba(17,17,17,0.5)] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_20px_40px_-12px_rgba(17,17,17,0.55)] disabled:cursor-not-allowed disabled:opacity-50"
          >
            <Search size={18} /> Reveal My Financial Damage
          </button>
          {!canSubmit && (
            <p className="mt-3 text-center text-xs text-muted-foreground">
              Enter your monthly income to begin the trial.
            </p>
          )}
        </form>

        <AnimatePresence>
          {analyzing && (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mt-6 space-y-3 rounded-3xl border border-border bg-white p-6 shadow-sm"
            >
              <div className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Running unscientific analysis…
              </div>
              {[
                "Analyzing financial mistakes...",
                "Calculating poor decisions...",
                "Estimating days of survival...",
                "Generating roast...",
              ].map((line, i) => (
                <TypewriterLine
                  key={line}
                  text={line}
                  delay={i * 600}
                  onDone={() => setDoneSteps((s) => Math.max(s, i + 1))}
                />
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}

/* ---------------- Footer ---------------- */
function Footer() {
  return (
    <footer id="about" className="relative border-t border-border bg-white">
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
        <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
          <div>
            <div className="font-display text-xl font-black">💸 BrokeCheck</div>
            <p className="mt-2 max-w-md text-sm text-muted-foreground">
              Built for financially struggling legends. No financial advisors were harmed
              in the making of this app.
            </p>
          </div>
          <nav className="flex flex-wrap gap-x-5 gap-y-2 text-sm font-medium">
            <a href="#home" className="hover:text-foreground/70">Home</a>
            <a href="#calculator" className="hover:text-foreground/70">Calculator</a>
            <a href="#roast" className="hover:text-foreground/70">Roast</a>
            <a href="#about" className="hover:text-foreground/70">About</a>
          </nav>
        </div>
        <div className="mt-8 border-t border-border pt-5 text-xs text-muted-foreground">
          © 2025 BrokeCheck. Your wallet may vary.
        </div>
      </div>
    </footer>
  );
}

/* ---------------- Index ---------------- */
function Index() {
  const [results, setResults] = useState<Computed | null>(null);
  const [showSplash, setShowSplash] = useState(true);
  const resultsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (showSplash) {
      document.body.style.overflow = "hidden";
      return () => {
        document.body.style.overflow = "";
      };
    }
  }, [showSplash]);

  const handleSubmit = (data: Computed) => {
    setResults(data);
    setTimeout(() => {
      resultsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 100);
  };

  return (
    <div className="grain relative min-h-screen overflow-x-hidden bg-background text-foreground">
      <AnimatePresence>
        {showSplash && <IntroSplash onDone={() => setShowSplash(false)} />}
      </AnimatePresence>
      <FloatingBackground />
      <div className="relative z-10">
        <Navbar />
        <main>
          <HeroSection />
          <HowItWorksSection />
          <CalculatorSection onSubmit={handleSubmit} />
          <div ref={resultsRef}>
            <AnimatePresence>
              {results && <ResultsSection key="results" data={results} />}
            </AnimatePresence>
          </div>
          <BadgesSection data={results} />
          <RoastGeneratorSection />
        </main>
        <Footer />
      </div>
    </div>
  );
}
